This lab was a bit hard to understand as far as what I should be doing (maybe I just was misinterpreting some directions so that could just be me)
I'm fairly sure my movies php works but I kept getting database access errors the day I was testing it so I can't know for sure.
Otherwise the lab wasn't too hard up until the 6th step which is where I began to have some trouble