I deleted the pre-existing css in the html file as I didn't want it to interfere with the css file I had just linked it to. (not sure it would be a problem but I'd rather test that later)
I also took my websites css and changed the #h1 to #directions to make it so the directions were laid out just like my h1 in my own website.
I left the other (#intructions) classes the same as I didn't think they needed to be changed as long as my overall style from my website was transferred to the given html file.
