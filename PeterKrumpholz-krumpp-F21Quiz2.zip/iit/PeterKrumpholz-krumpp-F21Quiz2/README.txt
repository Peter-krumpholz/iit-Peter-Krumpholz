GitHub: Peter-krumpholz
Repo: iit-Peter-krumpholz
Discord: Peter K '25 (krumpp) 
The widgets I added were meant to add some interactibility to my fairly basic website.
Besides the required widgets, the three I added were the ability to drag my projects around the projects page, as well as an accordion for my email and a modal window for my info.
I added the accordion and modal window to make my info pop out on the homepage rather than just be sitting there like they previously were. Additionally, the accordion can allow me to easily add many other tabs of info about contacting me, future jobs, etc.
The window was less about functionality like the accordion and was more about just having my info be front and center when you open the page. I honestly could have added anything but I thought this would easily catch your eye
I implemented the other widgets pretty easily (besides the lab instructions which I added seperate links to as they didn't all pop up when clicked on like I had hoped) I simply linked the function from my js to all the pop up links so the modal windows would appear when you click on them.
Additionally, the Labs folder contains my index.html and all the labs on my website. I just copied them all into the quiz folder.