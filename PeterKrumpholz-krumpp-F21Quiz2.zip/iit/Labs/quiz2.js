/* quiz 2 JavaScript File*/


$( function() {
  $( "#menu-q" ).menu();
} );

$( function() {
    $( "#dialog" ).dialog();
  } );

$( function() {
    $( "#draggable" ).draggable();
  } );

  $( function() {
    $( "#accordion" ).accordion();
  } );