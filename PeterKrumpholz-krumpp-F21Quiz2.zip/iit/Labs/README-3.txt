Lab 3: Website
https://afsws.rpi.edu/AFS/home/40/krumpp/public_html/iit/Index.html

Description: 
This is a website designed to be improved upon over my years at RPI. It is using 3 html files with a css file attached.
I enjoyed the lab but I wish I had more time to work out all the kinks and really decorate and format my website exaclty how I wanted. 
My files for this lab aren't contained in my lab 3 folder as if they are saved there, my links don't work. I need some more time to figure that out but I thought it better to leave the files a little messy and have it work fully than have to edit everything again.
My Index file doesn't open correctly when opened from the zip file but the link allows everything to work fine.