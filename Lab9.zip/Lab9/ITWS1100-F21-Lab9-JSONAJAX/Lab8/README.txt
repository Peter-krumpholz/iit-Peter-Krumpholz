<script>window.location.assign("http://www.rpi.edu");</script>  
From what I understand, the text we are putting in the comments is sent to the output area of the code. 
In that div though, the script tag that we put in the comments is read and then executed, taking us to the RPI homepage.