I thought this lab for XML and RSS was pretty easy once you figured out what to do for one link.
The part I struggled with the most was probably switching everything from RSS to Atom but even that was easily done after you completed it one time.
If I were to have to do this again I'd definitely stick to RSS as Atom just seemed to take a bit more time to format correctly and sitching from RSS to Atom was pretty tedious as well.

Link to my projects page:
file:///C:/Users/RCR%2014-12/Dropbox/PC/Documents/ITWS%201100/iit/Labs/projects.html