Honestly I'm not 100% sure my json works but I know it does something because if I edit it, it pops up with an error meaning it is executing it.
Everything besides my Json I'm 100% works on my projects page
I didn't make it so my projects page links to my home and labs pages as I don't think it was needed for this lab and I was focused more on trying to get the json right