$(document).ready(function() {
  
    
    var option=1;	
      
      if (option==1) {
      
        $.ajax({
              type: "GET",
              url: "lab9jsontemplate.json",
              dataType: "json",
              success: function(responseData, status){
               var output = "<ul>";  
               $.each(responseData.menuItem, function(i, item) {
                 output += '<li><a href="' + item.menuURL + '" target="_blank">';
              output += '<img title="' + item.menuName + '" src="' + item.menuDesc;
              output += '" alt="'; 
              output += item.menuUrl + '" />';
              output += '</a></li>';
            });
            output += "</ul>";
            $('#flickrOutput').html(output);
          }, error: function(msg) {
            alert("There was a problem: " + msg.status + " " + msg.statusText);
          }
        });
          }
        });
      