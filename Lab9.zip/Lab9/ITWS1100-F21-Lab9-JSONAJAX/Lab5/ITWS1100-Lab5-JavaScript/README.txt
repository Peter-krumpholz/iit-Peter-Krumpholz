Not too sure what to write in this. The lab was pretty straight foreward it was mostly just figuring out javascript for me.
My nickname function gave me some trouble for a long time but I realized that I had written getElemntsById with a s instead of just element which fixed it but took way too long to figure out on my end
Otherwise everything else wasn't too hard especially since I got help with the main error messages in class.
This link should work (at least it did for me):
https://afsws.rpi.edu/AFS/home/40/krumpp/public_html/iit/iit/iit/Labs/projects.html