This lab was pretty straight forward not too much to write about as far as what I did as we were guided through
Link:
https://afsws.rpi.edu/AFS/home/40/krumpp/public_html/iit/iit/iit/Labs/projects.html